
# CLAWBOLT Messenger Relay (Deploy on Render)
# Forwards messages to Local Core (Prevents Webhook Disabling)
#
# HOW IT WORKS:
# 1. Meta > Render (200 OK) -> Meta stops retrying.
# 2. Render > Local (Ngrok) -> Attempts to forward message.
#
# BENEFIT:
# - You never change Meta Console URL again.
# - You only update CLAWBOLT_CORE_URL in Render env (Easier API or Dashboard).

import os
import requests
import logging
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# Config
# Set these in Render Dashboard
VERIFY_TOKEN = os.getenv("MESSENGER_VERIFY_TOKEN", "clawbolt_verify_token")
CORE_URL = os.getenv("CLAWBOLT_CORE_URL") # e.g., https://xxxx.ngrok-free.app

# Configure Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@app.route("/", methods=["GET"])
def index():
    status = "Active" if CORE_URL else "Waiting for Core Link"
    return f"<h1>CLAWBOLT Relay Node</h1><p>Status: {status}</p><p>Core: {CORE_URL}</p>"

@app.route("/privacy", methods=["GET"])
def privacy():
    return render_template("legal/privacy.html")

@app.route("/terms", methods=["GET"])
def terms():
    return render_template("legal/terms.html")

# --- Webhook Verification ---
@app.route("/webhook", methods=["GET"])
def verify():
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")

    if mode and token:
        if mode == "subscribe" and token == VERIFY_TOKEN:
            logger.info("WEBHOOK_VERIFIED")
            return challenge, 200
        else:
            return "Verification Failed", 403
    return "Webhook Active", 200

# --- Message Relay ---
@app.route("/webhook", methods=["POST"])
def webhook():
    data = request.get_json()
    
    # 1. Acknowledge Meta Immediately (Prevents Disable)
    # Return 200 OK regardless of forwarding success
    # This keeps the bot "Verified" in Meta's eyes.

    if not CORE_URL:
        logger.warning("No Core URL set. Dropping message.")
        return "EVENT_RECEIVED", 200

    # 2. Background Forwarding (Async recommended, but simple timeout here)
    try:
        # Forward to local core webhook endpoint
        # The local core expects the same payload structure
        forward_url = f"{CORE_URL}/webhook"
        
        # We spawn a thread to forward so we don't block the return to Meta
        import threading
        thread = threading.Thread(target=forward_message, args=(forward_url, data))
        thread.start()
        
    except Exception as e:
        logger.error(f"Failed to spawn forward thread: {e}")

    return "EVENT_RECEIVED", 200

def forward_message(url, payload):
    try:
        requests.post(url, json=payload, timeout=5)
        logger.info(f"Forwarded to Core: {url}")
    except Exception as e:
        logger.error(f"Forward Failed: {e}")

# --- Core Registration Endpoint ---
# Allows local bot to update its URL automatically!
@app.route("/register_core", methods=["POST"])
def register_core():
    global CORE_URL
    secret = request.args.get("secret")
    # Simple security check (match verify token or add a new secret)
    if secret != VERIFY_TOKEN:
        return "Unauthorized", 401
    
    new_url = request.json.get("url")
    if new_url:
        CORE_URL = new_url.rstrip("/")
        logger.info(f"Updated Core URL: {CORE_URL}")
        return jsonify({"status": "updated", "url": CORE_URL}), 200
    return "Missing URL", 400

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
