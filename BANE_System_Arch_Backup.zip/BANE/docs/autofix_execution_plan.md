# BANE Auto-Fix Protocol: Execution Phase

This plan outlines the systematic repair of critical and moderate bugs identified during the system scan on February 15, 2026.

## Phase 1: Core Logic Repairs (Critical)

### 1.1 Fix Quota Detector Scoping (`antigravity/quota_detector.py`)
- **Issue**: `cv2` is used inside functions but the import might be shadowed or failing in certain runtime contexts due to dynamic reloads.
- **Fix**: Move `import cv2` inside the specific functions or ensure it's globally stable and handle the `NameError`.
- **Target**: `antigravity/quota_detector.py`

### 1.2 Implement Global Error Handler (`telegram_interface/bot.py`)
- **Issue**: No centralized error catching for Telegram updates.
- **Fix**: Add `application.add_error_handler(global_error_handler)` to log and notify Admin of crashes.
- **Target**: `telegram_interface/bot.py`

### 1.3 Decouple Blocking Async Loop (`core/router.py` & `utils/send_messenger.py`)
- **Issue**: Synchonous `requests` calls blocking the `async` event loop.
- **Fix**: Standardize on `asyncio.to_thread()` for all synchronous network calls in `handle_message` and `handle_messenger_message`.
- **Target**: `core/router.py`, `utils/send_messenger.py`, `utils/send_telegram.py`

## Phase 2: Optimization & Stability (Moderate)

### 2.1 Eliminate Duplicate Syncing (`core/router.py`)
- **Issue**: Double calls to `_sync_to_dashboard`.
- **Fix**: Remove the synchronous call and keep only the `asyncio.create_task` version.
- **Target**: `core/router.py`

### 2.2 Process Guard Enhancement (`main.py`)
- **Issue**: Lingering processes causing port conflicts.
- **Fix**: Implement a more aggressive `fuser -k` or PID tracking during startup to ensure previous instances are wiped.
- **Target**: `main.py`

## Phase 3: Validation
- Restart BANE service.
- Monitor `main.log` and `main_restart_final.log` for errors.
- Test real-time response while processing background tasks.
