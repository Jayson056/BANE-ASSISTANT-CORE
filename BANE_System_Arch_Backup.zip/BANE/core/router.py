# BANE - Created by Jayson056
# Copyright (c) 2026 Jayson056. All rights reserved.
import logging
import os
import asyncio
import json
import re
from datetime import datetime

# Telegram Imports
from telegram import Update, constants
from telegram.ext import ContextTypes
from telegram_interface.auth import is_authorized, is_admin_context
from telegram_interface.ui import accept_reject_keyboard

# Antigravity Imports
from antigravity.injector import send_to_antigravity
from antigravity.monitor import detect_state, get_error_details
from antigravity.button_mapper import detect_action_buttons

# Messenger Imports
from utils.send_messenger import send_messenger_text, send_messenger_reaction
from utils.message_history import save_message, get_message
from core import cortex_recall

logger = logging.getLogger(__name__)

SCREENSHOTS_DIR = "storage/screenshots"
VOICE_ENABLED = True

class UniversalProcessor:
    """
    Handles AI injection logic for all platforms (Telegram, Messenger).
    Abstracts transport layers (Updates/Payloads) into a unified pipeline.
    """

    @staticmethod
    async def process_request(
        platform: str,
        user_id: str,
        chat_id: str,
        message_text: str,
        attachments: list,
        reply_context: str,
        role: str,
        user_paths: dict,
        send_reply: callable,
        send_buttons: callable = None,
        context_data: dict = None
    ):
        """
        Generic processing pipeline:
        1. Context Construction
        2. Concurrency Check
        3. Dashboard Sync
        4. Injection to Antigravity
        5. Wait Loop & Response Detection
        """
        
        # 1. Platform Acknowledgment (Immediate)
        is_private = context_data.get("is_private", True)
        if platform == "messenger" and is_private:
            try:
                from utils.send_messenger import send_messenger_action
                # We mark as seen immediately to show the user we received it
                asyncio.create_task(send_messenger_action(user_id, "mark_seen"))
                # Also start typing to show we are working on it
                asyncio.create_task(send_messenger_action(user_id, "typing_on"))
            except: pass

        # 2. Concurrency Management
        state = detect_state()
        if state == "busy":
            if is_private:
                await send_reply("⚠️ **SYSTEM BUSY**\n\nThe AI is currently processing another request. Please wait.")
            return

        # 3. Dashboard Sync & Persistent History (Handled in background)
        try:
            from utils.logger import log_conversation_step
            log_text = message_text
            if attachments:
                log_text += f"\n[ATTACHMENTS: {', '.join([os.path.basename(a['path']) for a in attachments])}]"
            log_conversation_step(log_text, "user", user_id=user_id)
        except:
            pass

        # 4. Auto-Sort Attachments (School Organization)
        if attachments and user_paths.get('workspace'):
            sort_results = UniversalProcessor._auto_sort_attachments(user_id, user_paths, attachments)
            if sort_results:
                await send_reply(f"📁 **Auto-Sorted Attachments:**\n{sort_results}")

        # 3. Synchronize to Dashboard (Background - Latency Saver)
        asyncio.create_task(asyncio.to_thread(UniversalProcessor._sync_to_dashboard, user_id, message_text, attachments))

        # 4. Construct Full Message (Injection Payload) — Compressed context to save tokens
        chat_type_short = "Private" if is_private else "Group"
        user_hash = user_paths.get('hash', '?')
        # Abbreviated paths save ~100 tokens per message
        user_context_str = (
            f"\n\n[CTX] U:{user_id} C:{chat_id} P:{platform} "
            f"H:{user_hash} T:{chat_type_short} R:{role}\n"
            f"WS:~W/{user_hash} | ST:~S/{user_hash} | isolation:ON"
        )

        full_message = f"{message_text}{reply_context}{user_context_str}"
        
        # Append attachment info
        if attachments:
            for att in attachments:
                full_message += f"\n\n📎 **ATTACHED {att['type'].upper()}:**\nPath: `{att['path']}`"

        if not full_message.strip() and attachments:
             full_message = f"User sent {len(attachments)} attachments."

        # 5. CORTEX QUOTA GUARD (Proactive Bypass)
        u_hash = user_paths.get('hash', '?')
        quota_cfg = cortex_recall.get_degradation_config()
        
        # Check for static/smart recall even if NOT in quota mode (saves tokens)
        if not quota_cfg["use_ai"] or role == "guest":
            q_fallback = cortex_recall.handle_quota_mode(u_hash, message_text, bool(attachments))
            is_limit = cortex_recall.is_quota_exceeded()
            
            # Refined bypass: only static, strong smart recall, or school fallback (if limit)
            should_bypass = False
            if q_fallback:
                mode = q_fallback["mode"]
                conf = q_fallback.get("confidence", 0)
                if mode == "static":
                    should_bypass = True
                elif mode == "cortex_recall" and conf > 0.8:
                    should_bypass = True
                elif mode == "school_fallback" and is_limit:
                    should_bypass = True
                elif mode == "cortex_last" and is_limit:
                    should_bypass = True

            if should_bypass and q_fallback["mode"] != "quota_block":
                logger.info(f"⚡ CORTEX BYPASS [{q_fallback['mode']}]: Providing zero-token reply.")
                await send_reply(q_fallback["text"])
                return

        logger.info(f"Injecting message from {platform.upper()} User {user_id}")

        # 6. Inject to Antigravity (Offload blocking GUI automation to thread)
        success, status = await asyncio.to_thread(send_to_antigravity, full_message)

        if success:
            await asyncio.sleep(1.0)
            
            # Immediate error check
            new_state = detect_state()
            if new_state == "error":
                error_msg = get_error_details()
                model = os.getenv("ANTIGRAVITY_MODEL", "Unknown")
                
                # Update persistent state so future calls use recall immediately
                cortex_recall.set_quota_state(error_msg, model)
                
                # Get the best available fallback from Cortex
                fallback_data = cortex_recall.handle_quota_mode(u_hash, message_text, bool(attachments))
                await send_reply(fallback_data["text"])
            else:
                # 7. Enter Wait Loop
                await UniversalProcessor._wait_loop(platform, send_reply, send_buttons, is_private, message_text)
        else:
            await send_reply(f"❌ **Injection Failed**\n\n{status}")
            if "editor zone" in status.lower() or "Targeting error" in status:
                await send_reply("🛠️ **Detected Targeting Error.** Launching automated self-fix...")
                # Note: Self-fix requires original bot context usually, we might skip for generic or implement generic self-fix
                pass

    @staticmethod
    def _sync_to_dashboard(user_id, text, attachments):
        try:
            chat_file = "/home/son/BANE/dashboard/chat_history.json"
            history = []
            if os.path.exists(chat_file):
                with open(chat_file, 'r') as f:
                    history = json.load(f)
            
            log_text = f"[User {user_id}] {text}"
            if attachments:
                log_text += f" [Attachments: {len(attachments)}]"
            
            history.append({
                "role": "user", 
                "text": log_text, 
                "user_id": user_id, 
                "time": datetime.now().isoformat()
            })
            
            if len(history) > 100: history = history[-100:]
            with open(chat_file, 'w') as f:
                json.dump(history, f, indent=2)
        except Exception as e:
            logger.error(f"Dashboard sync failed: {e}")

    @staticmethod
    def _auto_sort_attachments(user_id, user_paths, attachments):
        """Attempts to move attachments to matching School subject folders."""
        school_dir = os.path.join(user_paths['workspace'], "School")
        if not os.path.exists(school_dir):
            return None
        
        subjects = [d for d in os.listdir(school_dir) if os.path.isdir(os.path.join(school_dir, d))]
        if not subjects:
            return None
            
        results = []
        import subprocess
        import shutil
        
        for att in attachments:
            path = att['path']
            filename = os.path.basename(path).lower()
            content = ""
            
            # Extract content for matching
            if path.lower().endswith('.pdf'):
                try:
                    proc = subprocess.run(['pdftotext', path, '-'], capture_output=True, text=True, timeout=5)
                    content = proc.stdout.lower()
                except: pass
            
            # Match strategy
            matched_subject = None
            for sub in subjects:
                # Clean subject name for matching (e.g. "COMP 026 - Principles of Systems Thinking" -> keywords)
                keywords = [k for k in sub.replace("-", " ").lower().split() if len(k) > 3]
                if any(kw in filename for kw in keywords) or (content and any(kw in content for kw in keywords)):
                    matched_subject = sub
                    break
            
            if matched_subject:
                dest_dir = os.path.join(school_dir, matched_subject)
                # If there's an 'Instructional Materials' or similar folder, prefer it
                for sub_dir in ["Instructional Materials", "Materials", "Notes"]:
                    if os.path.exists(os.path.join(dest_dir, sub_dir)):
                        dest_dir = os.path.join(dest_dir, sub_dir)
                        break
                
                try:
                    new_path = os.path.join(dest_dir, os.path.basename(path))
                    shutil.move(path, new_path)
                    att['path'] = new_path # Update path for injection context
                    results.append(f"• `{os.path.basename(path)}` → `{matched_subject}`")
                except Exception as e:
                    logger.error(f"Failed to move {filename}: {e}")
                    
        return "\n".join(results) if results else None

    @staticmethod
    async def _wait_loop(platform, send_reply, send_buttons, is_private, original_text):
        """
        Monitors Antigravity UI for completion/buttons.
        """
        max_wait = 150
        waited = 0
        detected = False
        
        # Heuristic for detecting code edits
        is_code_edit = any(kw in original_text.lower() for kw in ["edit", "code", "change", "add", "remove", "update", "fix", "implement", "refactor"])

        while waited < max_wait:
            state = detect_state()
            
            # Check for buttons (File Changes)
            buttons = detect_action_buttons()
            if buttons:
                from agent.turbo import get_automation_state
                if get_automation_state()["autonomous"] and "accept_all" in buttons:
                    from antigravity.button_mapper import click_button
                    logger.info("⚡ Real-time Turbo: Auto-clicking Accept ALL")
                    click_button(buttons["accept_all"])
                    # Reset wait and continue monitoring for next step
                    waited = 0
                    await asyncio.sleep(5)
                    continue

                if send_buttons:
                    await send_buttons() # Trigger platform-specific button render
                detected = True
                break
            
            if state == "idle" and waited > 2:
                # Double check
                await asyncio.sleep(0.5)
                buttons = detect_action_buttons()
                if buttons and send_buttons:
                    await send_buttons()
                    detected = True
                break
            elif state == "error":
                return

            await asyncio.sleep(0.5)
            waited += 0.5
        
        if not detected and is_code_edit and is_private and send_buttons:
             # Fallback
             await send_buttons()


# --- Platform Handlers ---

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    TELEGRAM HANDLER (Legacy Adapter)
    Routes Telegram updates to UniversalProcessor.
    """
    user = update.effective_user
    if not user or not is_authorized(user.id):
        return

    from utils.user_manager import get_user_paths
    user_paths = get_user_paths(user.id)
    
    message = update.message
    message_text = message.text or message.caption or ""
    
    # Attachment Handling (Telegram Specific)
    attachments = []
    user_received_dir = user_paths["received"]
    
    try:
        file = None
        file_type = None
        if message.photo:
            file = await context.bot.get_file(message.photo[-1].file_id)
            file_type = "Image"
            dest = f"photo_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
        elif message.document:
            file = await context.bot.get_file(message.document.file_id)
            file_type = "Document"
            dest = message.document.file_name
        elif message.voice:
            file = await context.bot.get_file(message.voice.file_id)
            file_type = "Voice"
            dest = f"voice_{datetime.now().strftime('%Y%m%d_%H%M%S')}.ogg"
        elif message.video:
            file = await context.bot.get_file(message.video.file_id)
            file_type = "Video"
            orig_name = message.video.file_name
            ext = os.path.splitext(orig_name)[1] if orig_name else ".mp4"
            dest = f"video_{datetime.now().strftime('%Y%m%d_%H%M%S')}{ext}"
        elif message.audio:
            file = await context.bot.get_file(message.audio.file_id)
            file_type = "Audio"
            orig_name = message.audio.file_name
            ext = os.path.splitext(orig_name)[1] if orig_name else ".mp3"
            dest = f"audio_{datetime.now().strftime('%Y%m%d_%H%M%S')}{ext}"
        elif message.video_note:
            file = await context.bot.get_file(message.video_note.file_id)
            file_type = "VideoNote"
            dest = f"video_note_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp4"
        
        if file:
            full_dest = os.path.join(user_received_dir, dest)
            await file.download_to_drive(full_dest)
            attachments.append({"type": file_type, "path": os.path.abspath(full_dest)})
            
            # STT Hook
            if file_type == "Voice":
                try:
                    from utils.speech_to_text import transcribe_audio
                    transcript, error = transcribe_audio(os.path.abspath(full_dest))
                    if transcript:
                         message_text = f"[TRANSCRIPT]: \"{transcript}\"\n\n{message_text}"
                except Exception:
                    pass

    except Exception as e:
        logger.error(f"Attachment download failed: {e}")
        await update.message.reply_text(f"⚠️ Failed to receive attachment: {e}")

    # Persist ID, Content, and Attachments for Contextual Replies
    try:
        if message.message_id:
             # Use string ID for consistency
             save_message(str(message.message_id), message_text, sender_id=str(user.id), attachments=attachments)
    except Exception as e:
        logger.error(f"Failed to save Telegram context: {e}")

    # Reply Context
    reply_context = ""
    if message.reply_to_message:
        orig = message.reply_to_message
        sender = orig.from_user.first_name if orig.from_user else "System"
        txt = orig.text or orig.caption or "[Media]"
        reply_context = f"\n\n💬 **REPLY CONTEXT (Replying to {sender}):**\n> \"{txt}\""
        
        # Pull historical attachments
        parent_id = str(orig.message_id)
        parent_msg = get_message(parent_id)
        if parent_msg:
             hist_atts = parent_msg.get("attachments", [])
             if hist_atts:
                  logger.info(f"📁 Adding {len(hist_atts)} historical attachments from Telegram reply.")
                  attachments.extend(hist_atts)

    # Role
    chat = update.effective_chat
    role = "admin" if is_admin_context(update) else "guest"
    
    # Callbacks
    async def telegram_reply(text):
        # 1. Immediate Text Delivery (Non-blocking)
        try:
            from utils.send_telegram import _send_single_message_and_get_id, _update_last_message
            import re
            
            # Robust Markdown (**bold**) to HTML (<b>bold</b>) converter for Telegram
            html_text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
            
            # Send the text first with HTML support
            text_task = asyncio.create_task(asyncio.to_thread(_send_single_message_and_get_id, html_text, "HTML"))
            
            # 2. Intelligent TTS Skip Logic
            if not text.strip(): return
            
            # 3. Background Voice Generation (Parallel)
            reply_to_id = update.message.message_id if update.message else None
            
            async def process_voice_background(target_reply_id):
                try:
                    from utils.text_to_speech import text_to_ogg
                    success, audio_path = await asyncio.to_thread(text_to_ogg, text, voice_id="nova")
                    
                    if success and audio_path:
                        import requests
                        from utils.send_telegram import API_URL
                        
                        with open(audio_path, 'rb') as voice_file:
                            data = {"chat_id": chat.id}
                            if target_reply_id:
                                data["reply_to_message_id"] = target_reply_id
                                
                            v_res = requests.post(API_URL + "sendVoice", data=data, files={"voice": voice_file}, timeout=30)
                            if v_res.status_code == 200:
                                v_msg_id = v_res.json()["result"]["message_id"]
                                _update_last_message(chat.id, v_msg_id)
                        
                        if os.path.exists(audio_path):
                            os.remove(audio_path)
                except Exception as e:
                    logger.error(f"Background Voice Delivery Failed: {e}")

            asyncio.create_task(process_voice_background(reply_to_id))
            
            msg_id = await text_task
            if msg_id:
                _update_last_message(chat.id, msg_id)
                # Save bot's reply to history
                try:
                    save_message(str(msg_id), text, sender_id="system")
                except: pass
                
        except Exception as e:
            logger.error(f"Telegram Async Reply Failed: {e}")

    async def telegram_buttons():
        await _send_file_change_notification(update, context)

    await UniversalProcessor.process_request(
        platform="telegram",
        user_id=str(user.id),
        chat_id=str(chat.id),
        message_text=message_text,
        attachments=attachments,
        reply_context=reply_context,
        role=role,
        user_paths=user_paths,
        send_reply=telegram_reply,
        send_buttons=telegram_buttons,
        context_data={"is_private": chat.type == constants.ChatType.PRIVATE}
    )

async def _send_file_change_notification(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Telegram-specific UI for file changes."""
    chat_id = update.effective_chat.id
    # Collapse previous
    if context.chat_data and "last_file_change_msg_id" in context.chat_data:
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=context.chat_data["last_file_change_msg_id"],
                text="✅ File changes detected (see latest notification below)"
            )
        except: pass
    
    sent_msg = await update.message.reply_text(
        "🔧 **AI has made changes to files.**\n\nChoose an action:",
        reply_markup=accept_reject_keyboard()
    )
    if context.chat_data is None: context.chat_data = {}
    context.chat_data["last_file_change_msg_id"] = sent_msg.message_id


async def handle_messenger_message(payload: dict, recipient_id: str, access_token: str):
    """
    MESSENGER HANDLER (New)
    Routes Messenger webhooks to UniversalProcessor.
    """
    # DEBUG: Log full payload to see what's actually looping
    logger.info(f"DEBUG_PAYLOAD: {json.dumps(payload)}")

    sender_id = payload.get('sender', {}).get('id')
    message_obj = payload.get('message', {})
    reaction_obj = payload.get('reaction')
    
    text = ""
    mid = ""
    
    if message_obj:
        text = message_obj.get('text', "")
        mid = message_obj.get('mid')
    elif reaction_obj:
        # Handle Reaction
        mid = reaction_obj.get('mid') # Original message ID
        emoji = reaction_obj.get('emoji', "")
        action = reaction_obj.get('action', "") # 'react' or 'unreact'
        
        if action == "react":
            parent_msg = get_message(mid)
            parent_text = parent_msg.get('text', '[Unknown content]') if parent_msg else '[Unknown content]'
            text = f"[REACTION]: User reacted with {emoji} to your message: \"{parent_text}\""
            logger.info(f"❤️ Reaction detected: {emoji} on {mid}")
        else:
            return # Ignore unreacts for now to save tokens

    # --- Start Automated Reaction Logic (Multilingual Atmospheric Analyzer) ---
    if mid and sender_id and not message_obj.get('is_echo'):
        msg_text_raw = message_obj.get('text', "") or ""
        has_attachments = 'attachments' in message_obj
        logger.info(f"🔍 Checking Auto-Reaction for: '{msg_text_raw[:30]}' (Attachments: {has_attachments})")
        
        try:
            from utils.emotion_lexicon import get_reaction_for_message, analyze_message_emotion
            
            # Get reaction from the multilingual atmospheric analyzer
            reaction_to_send = get_reaction_for_message(msg_text_raw, has_attachments=has_attachments)
            
            # Debug: log the emotion analysis result
            emotion, confidence, _ = analyze_message_emotion(msg_text_raw)
            if emotion:
                logger.info(f"🧠 Emotion Analysis: {emotion} (confidence: {confidence:.2f})")
            
        except ImportError as e:
            logger.error(f"⚠️ emotion_lexicon not available, falling back to basic: {e}")
            # Minimal fallback if module fails to load
            reaction_to_send = None
            msg_text_l = msg_text_raw.lower()
            if has_attachments:
                reaction_to_send = "❤️"
            elif any(kw in msg_text_l for kw in ["haha", "hehe", "lol", "😂", "🤣"]):
                reaction_to_send = "😂"
            elif any(kw in msg_text_l for kw in ["love", "thanks", "salamat", "galing", "❤️"]):
                reaction_to_send = "❤️"

        if reaction_to_send:
            async def trigger_auto_reaction(rid, m_id, react, tok):
                try:
                    logger.info(f"✨ Auto-Reacting with {react} to MID: {m_id}")
                    await asyncio.sleep(0.8) # Natural delay
                    result = await asyncio.to_thread(send_messenger_reaction, rid, m_id, react, tok)
                    if result:
                        logger.info(f"✅ Reaction {react} delivered to {m_id[:20]}...")
                    else:
                        logger.warning(f"⚠️ Reaction {react} may have failed for {m_id[:20]}...")
                except Exception as e:
                    logger.error(f"Auto-Reaction failed: {e}")
            
            asyncio.create_task(trigger_auto_reaction(sender_id, mid, reaction_to_send, access_token))
        else:
            logger.debug(f"No emotion match for: '{msg_text_raw[:30]}'")
    # --- End Automated Reaction Logic ---

    # Messenger often loops back the bot's own status messages as new inputs.
    SYSTEM_PREFIXES = ["⌛", "⚠️", "❌", "🔧", "✅"]
    if text and any(text.startswith(pref) for pref in SYSTEM_PREFIXES):
        logger.debug(f"Ignoring system message from {sender_id}: {text[:20]}...")
        return

    if message_obj.get('is_echo'):
        return
    
    #  Deduplication
    cache_key = mid
    if reaction_obj:
        cache_key = f"react_{mid}_{reaction_obj.get('action')}_{reaction_obj.get('emoji')}"

    if not hasattr(handle_messenger_message, "_mid_cache"):
        handle_messenger_message._mid_cache = set()
    
    if cache_key in handle_messenger_message._mid_cache:
        logger.debug(f"Ignoring duplicate Messenger event: {cache_key}")
        return
    
    handle_messenger_message._mid_cache.add(cache_key)
    if len(handle_messenger_message._mid_cache) > 100:
        handle_messenger_message._mid_cache.remove(next(iter(handle_messenger_message._mid_cache)))

    if not sender_id: return

    # User Auth & Paths
    from utils.user_manager import get_user_paths, initialize_user
    is_new, notice = initialize_user(sender_id, platform="messenger")
    
    if is_new and notice:
        send_messenger_text(sender_id, notice, access_token, reply_to_mid=mid)
    
    user_paths = get_user_paths(sender_id, platform="messenger")
    role = "admin" if str(sender_id) == os.getenv("MESSENGER_ADMIN_ID", "10087904874667208") else "guest"

    # Admin Commands (Messenger)
    if text and text.strip().lower() == "/reset_quota":
        from core import cortex_recall
        cortex_recall.clear_quota_state()
        send_messenger_text(sender_id, "✅ **Quota State Cleared.** Live AI model is now re-enabled.", access_token, reply_to_mid=mid)
        return

    # Attachments
    attachments = []
    if 'attachments' in message_obj:
        import requests
        user_received_dir = user_paths["received"]
        
        for att in message_obj['attachments']:
            try:
                att_type = att['type']
                url = att['payload'].get('url')
                if not url: continue
                
                import posixpath
                from urllib.parse import urlparse
                path = urlparse(url).path
                ext = posixpath.splitext(path)[1]
                if not ext:
                    if att_type == 'image': ext = '.jpg'
                    elif att_type == 'audio': ext = '.mp3'
                    elif att_type == 'video': ext = '.mp4'
                    else: ext = '.file'
                
                filename = f"{att_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}{ext}"
                dest_path = os.path.join(user_received_dir, filename)
                
                res = await asyncio.to_thread(requests.get, url, stream=True, timeout=30)
                res.raise_for_status()
                with open(dest_path, 'wb') as f:
                    for chunk in res.iter_content(chunk_size=8192):
                        f.write(chunk)
                
                attachments.append({
                    "type": att_type.capitalize(),
                    "path": os.path.abspath(dest_path)
                })
                logger.info(f"Downloaded Messenger attachment: {filename}")
            except Exception as e:
                logger.error(f"Failed to download Messenger attachment: {e}")

    # Persist MID
    try:
        if mid:
            save_message(mid, text, sender_id=sender_id, attachments=attachments)
            
        mid_file = "/home/son/BANE/storage/last_user_mids.json"
        data = {}
        if os.path.exists(mid_file):
            with open(mid_file, 'r') as f:
                data = json.load(f)
        data[str(sender_id)] = mid
        with open(mid_file, 'w') as f:
            json.dump(data, f)
    except Exception as e:
        logger.error(f"Failed to save Messenger context: {e}")

    # Callbacks
    async def messenger_reply(text):
        try:
            # Send text only — Voice/TTS disabled for Messenger (saves 2-5s per reply)
            res_json = await asyncio.to_thread(send_messenger_text, sender_id, text, access_token, reply_to_mid=mid)
            
            if res_json and "message_id" in res_json:
                 try: save_message(res_json["message_id"], text, sender_id="system")
                 except: pass
        except Exception as e:
            logger.error(f"Messenger Async Reply Failed: {e}")

    async def messenger_buttons():
        pass

    # Reply Context Extraction
    reply_context = ""
    reply_to = message_obj.get("reply_to")
    if reply_to:
        reply_mid = reply_to.get("mid")
        if reply_mid:
            parent_msg = get_message(reply_mid)
            if parent_msg:
                 txt = parent_msg.get("text", "[Unknown]")
                 sender_label = "System" if parent_msg.get("sender_id") == "system" else "User"
                 reply_context = f"\n\n💬 **REPLY CONTEXT (Replying to {sender_label}):**\n> \"{txt}\""
                 hist_atts = parent_msg.get("attachments", [])
                 if hist_atts:
                      attachments.extend(hist_atts)
            else:
                 reply_context = f"\n\n💬 **REPLY CONTEXT:**\n> [Original message content lost]"

    # ============================================================
    # ⚡ CORTEX RECALL / LIGHT MODE BYPASS
    # ============================================================
    # Priority zero-token response path.
    if text and not reaction_obj:
        from core import cortex_recall
        u_hash = user_paths.get('hash', '?')
        q_fallback = cortex_recall.handle_quota_mode(u_hash, text, bool(attachments))
        
        # LOGIC REFINEMENT:
        # 1. If quota IS exceeded, we MUST bypass (always use q_fallback if valid).
        # 2. If quota is FINE, we ONLY bypass for very high confidence (Static or SmartRecall > 0.8).
        
        is_limit = cortex_recall.is_quota_exceeded()
        # Refined recall: 80% similarity threshold to ensure 'sentence-level' matching
        # Note: school_fallback only bypasses if quota is exceeded to prevent annoying triggers on general questions.
        # Smart Recall (cortex_recall) still bypasses if confidence > 0.8.
        is_strong_match = False
        if q_fallback:
            mode = q_fallback["mode"]
            conf = q_fallback.get("confidence", 0)
            
            if mode == "static":
                is_strong_match = True
            elif mode == "cortex_recall" and conf > 0.8:
                is_strong_match = True
            elif mode == "school_fallback" and is_limit:
                is_strong_match = True
        
        if is_limit or is_strong_match:
            if q_fallback and q_fallback["mode"] != "quota_block":
                logger.info(f"⚡ CORTEX BYPASS [{q_fallback['mode']}]: '{text[:20]}...' (Limit={is_limit}, Confidence={q_fallback.get('confidence')})")
                await messenger_reply(q_fallback["text"])
                return
    # ============================================================
    # ============================================================

    await UniversalProcessor.process_request(
        platform="messenger",
        user_id=str(sender_id),
        chat_id=str(sender_id),
        message_text=text,
        attachments=attachments,
        reply_context=reply_context, 
        role=role,
        user_paths=user_paths,
        send_reply=messenger_reply,
        send_buttons=messenger_buttons,
        context_data={"is_private": True, "reply_to_mid": mid} 
    )
