#!/bin/bash
# fast-switch to sandbox
echo "SANDBOX_EXAMPLE" > /home/son/CLAWBOLT/antigravity/current_skill.txt
echo "Switched active skill to: SANDBOX_EXAMPLE"
