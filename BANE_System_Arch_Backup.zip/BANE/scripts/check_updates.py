import requests
import json

BOT_TOKEN = "7961814507:AAH8d2r4erdsEtGl88U99Q9HehFixQ4tBlo"
API_URL = f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates"

response = requests.get(API_URL)
print(json.dumps(response.json(), indent=2))
