import requests
import json

BOT_TOKEN = "7961814507:AAH8d2r4erdsEtGl88U99Q9HehFixQ4tBlo"
API_URL = f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates"

params = {"offset": -10} # Get last 10 updates
response = requests.get(API_URL, params=params)
data = response.json()

if data.get("ok"):
    for update in data["result"]:
        # Check message
        if "message" in update:
            chat = update["message"]["chat"]
            print(f"Message in: {chat.get('title', 'Private')} ({chat['id']})")
        # Check my_chat_member (when bot is added)
        if "my_chat_member" in update:
            chat = update["my_chat_member"]["chat"]
            print(f"Added to: {chat.get('title')} ({chat['id']})")
        # Check chat_member
        if "chat_member" in update:
            chat = update["chat_member"]["chat"]
            print(f"Member update in: {chat.get('title')} ({chat['id']})")
else:
    print(f"Error: {data}")
