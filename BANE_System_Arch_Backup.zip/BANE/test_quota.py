import os
import sys

# Try to find the BANE directory
bane_dir = "/home/son/BANE"
if os.path.exists(bane_dir):
    # Insert at the very beginning
    sys.path.insert(0, bane_dir)
    print(f"Added {bane_dir} to sys.path")

# List what's in BANE/utils
print(f"Contents of {bane_dir}/utils:")
try:
    print(os.listdir(os.path.join(bane_dir, "utils")))
except:
    print("Could not list BANE/utils")

try:
    import utils
    print(f"Imported utils from: {utils.__file__ if hasattr(utils, '__file__') else 'unknown'}")
    
    # Force import from local file if needed
    import importlib.util
    spec = importlib.util.spec_from_file_location("utils.ocr_helper", os.path.join(bane_dir, "utils/ocr_helper.py"))
    ocr_helper = importlib.util.module_from_spec(spec)
    sys.modules["utils.ocr_helper"] = ocr_helper
    spec.loader.exec_module(ocr_helper)
    print("Successfully manual-imported utils.ocr_helper")

    from antigravity.quota_detector import extract_quota_details
    print("Successfully imported extract_quota_details")
    data = extract_quota_details()
    print(f"Quota details: {data}")
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
