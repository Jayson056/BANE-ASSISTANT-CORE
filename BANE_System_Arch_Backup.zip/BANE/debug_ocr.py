# BANE - Created by Jayson056
# Copyright (c) 2026 Jayson056. All rights reserved.
import pytesseract
import cv2
import numpy as np
import pyautogui
from PIL import Image

def debug():
    screenshot = pyautogui.screenshot()
    img = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    
    # Preprocessing
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if np.mean(gray) < 127:
        gray = cv2.bitwise_not(gray)
    
    data = pytesseract.image_to_data(gray, output_type=pytesseract.Output.DICT, config='--psm 11')
    
    print(f"Screen size: {screenshot.size}")
    
    matches = []
    for i, text in enumerate(data["text"]):
        t = text.lower().strip()
        if t:
            # Check context
            context = " ".join(data["text"][max(0, i-5):i+5]).lower()
            if any(k in context for k in ["ask", "anything", "mention", "workflow", "ctrl"]):
                print(f"FOUND candidate: '{text}' at ({data['left'][i]}, {data['top'][i]}) width={data['width'][i]} height={data['height'][i]}")
                print(f"  Context: {context}")
                matches.append(i)

    if not matches:
        print("NO KEYWORDS FOUND IN OCR")
        # Print all detected words to see what's happening
        all_words = " ".join([t for t in data["text"] if t.strip()])
        print(f"RAW OCR OUTPUT: {all_words[:500]}...")

debug()
