import os
import glob
import logging

def extract_printable_text(file_path):
    """
    Heuristic to extract printable text from Antigravity .pb conversation files.
    Ported from 'CountTokens' VS Code extension logic.
    """
    try:
        with open(file_path, "rb") as f:
            buffer = f.read()
        
        filtered = bytearray()
        for b in buffer:
            # Logic: printable ASCII (32-126), \t (9), \n (10), \r (13), or UTF-8 high bits (>=128)
            if (32 <= b <= 126) or b in [9, 10, 13] or b >= 128:
                filtered.append(b)
        
        # Decode as UTF-8, ignore errors for corrupted parts
        text = filtered.decode("utf-8", errors="ignore")
        return text
    except Exception as e:
        return f"Error: {str(e)}"

def count_tokens(text):
    # For now, a rough estimate (4 chars per token)
    # In production, we can use a proper tokenizer if available
    return len(text) // 4

if __name__ == "__main__":
    conv_dir = os.path.expanduser("~/.gemini/antigravity/conversations")
    pb_files = glob.glob(os.path.join(conv_dir, "*.pb"))
    
    if not pb_files:
        print("No .pb files found.")
        exit()
    
    # Sort by modification time to get the latest
    pb_files.sort(key=os.path.getmtime, reverse=True)
    latest_file = pb_files[0]
    
    print(f"Parsing latest conversation: {os.path.basename(latest_file)}")
    text = extract_printable_text(latest_file)
    
    # Print first 200 chars for preview
    print("\nText Preview (Target Content):")
    print(text[:500] + "...")
    
    print(f"\nEstimated Tokens: {count_tokens(text)}")
