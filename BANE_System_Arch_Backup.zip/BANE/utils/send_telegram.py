import argparse
import requests
import time
import os
import json
import subprocess
import sys

# Configuration (Mirrored from telegram_bridge.py)
BOT_TOKEN = "7961814507:AAH8d2r4erdsEtGl88U99Q9HehFixQ4tBlo"
AUTHORIZED_CHAT_ID = 5662168844
API_URL = f"https://api.telegram.org/bot{BOT_TOKEN}/"
LAST_MSG_FILE = "/home/son/BANE/storage/last_ai_messages.json"

def _update_last_message(chat_id, message_id):
    """Stores the last message ID for a given chat."""
    try:
        data = {}
        if os.path.exists(LAST_MSG_FILE):
            with open(LAST_MSG_FILE, "r") as f:
                data = json.load(f)
        data[str(chat_id)] = message_id
        with open(LAST_MSG_FILE, "w") as f:
            json.dump(data, f)
    except:
        pass

def get_last_message_id(chat_id):
    """Retrieves the last message ID for a given chat."""
    try:
        if os.path.exists(LAST_MSG_FILE):
            with open(LAST_MSG_FILE, "r") as f:
                data = json.load(f)
                return data.get(str(chat_id))
    except:
        pass
    return None

# Global variables
CURRENT_CHAT_ID = AUTHORIZED_CHAT_ID 
CURRENT_REPLY_TO = None
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB

def delete_message(chat_id, message_id):
    """Deletes a message from Telegram."""
    if not message_id:
        return False
    try:
        url = API_URL + "deleteMessage"
        data = {"chat_id": chat_id, "message_id": message_id}
        requests.post(url, json=data, timeout=10)
        print(f"🗑️ Message {message_id} in {chat_id} deleted successfully.")
        return True
    except Exception as e:
        print(f"Failed to delete message: {e}")
        return False

def contains_sensitive_info(text):
    """Detects if a message contains system paths or sensitive keys."""
    if not text:
        return False
    sensitive_patterns = [
        "/home/son/",
        "BOT_TOKEN",
        "AUTHORIZED_CHAT_ID",
        "API_URL",
        "PASSWORD",
        "PRIVATE_KEY"
    ]
    return any(pattern in text for pattern in sensitive_patterns)

def schedule_deletion(chat_id, message_id, delay_seconds):
    """Schedules a message for deletion after a delay."""
    if not message_id:
        return
    # Run in background to avoid blocking the main script
    cmd = f"sleep {delay_seconds} && {sys.executable} {os.path.abspath(__file__)} --delete {message_id} --chat_id {chat_id}"
    subprocess.Popen(cmd, shell=True)
    print(f"🕒 Message {message_id} scheduled for deletion in {delay_seconds}s.")

def get_current_skill_info():
    """Reads the current skill name for the header."""
    try:
        state_file = "/home/son/BANE/antigravity/current_skill.txt"
        if os.path.exists(state_file):
            with open(state_file, "r") as f:
                skill_id = f.read().strip()
                mapping = {
                    "WORKSPACE": "WORKSPACE",
                    "CORE_MAINTENANCE": "CORE MAINTENANCE",
                    "AI_ARCHITECT": "AI ARCHITECT",
                    "CYBER_SECURITY": "CYBERSECURITY",
                    "PROJECT_LEAD": "PROJECT LEAD",
                    "PROGRAMMING_TASK": "PROGRAMMING",
                    "BUG_HUNTER": "BUG HUNTER",
                    "SANDBOX_EXAMPLE": "SANDBOX MODE"
                }
                return mapping.get(skill_id, skill_id.replace("_", " "))
    except:
        pass
    return "SYSTEM"

def format_premium(text, title=None):
    """Wraps text in a premium design skin (Minimal version)."""
    if not text:
        return ""
    
    status_icon = ""
    if "✅" not in text and "❌" not in text and "⚠️" not in text:
        lower_text = text.lower()
        if any(kw in lower_text for kw in ["success", "completed", "done", "fixed"]):
            status_icon = "✅ "
        elif any(kw in lower_text for kw in ["error", "fail", "failed"]):
            status_icon = "❌ "
        elif "warning" in lower_text:
            status_icon = "⚠️ "
    
    return f"{status_icon}{text}"

def _log_to_dashboard(text, role):
    try:
        import datetime
        chat_file = "/home/son/BANE/dashboard/chat_history.json"
        
        history = []
        if os.path.exists(chat_file):
            try:
                with open(chat_file, 'r') as f:
                    history = json.load(f)
            except:
                history = []
        
        history.append({
            "role": role,
            "text": text,
            "time": datetime.datetime.now().isoformat()
        })
        
        if len(history) > 100:
            history = history[-100:]
            
        with open(chat_file, 'w') as f:
            json.dump(history, f, indent=2)
    except Exception as e:
        print(f"Failed to log to dashboard: {e}")

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("text", nargs="?", default="")
    parser.add_argument("--voice", help="Path to voice file")
    parser.add_argument("--voice_text", help="Combined mode: path to voice file, sends voice+text as ONE message")
    parser.add_argument("--document", help="Path to document file")
    parser.add_argument("--chat_id", type=int, default=AUTHORIZED_CHAT_ID, help="Telegram Chat ID")
    parser.add_argument("--title", help="Custom title for the premium header")
    parser.add_argument("--parse_mode", default="Markdown")
    parser.add_argument("--reply_to", type=int, help="Message ID to reply to")
    parser.add_argument("--delete", type=int, help="Message ID to delete")
    parser.add_argument("--delete_previous", type=int, help="Previous message ID to delete before sending")
    parser.add_argument("--delete_auto", action="store_true", help="Automatically delete the last AI message in this chat")
    parser.add_argument("--delete_after", type=int, help="Seconds to wait before deleting")
    return parser.parse_args()

def send_message(text, parse_mode="Markdown", title=None, retries=3, delete_after=None, delete_previous=None):
    if not text:
        return None
    
    is_sensitive = contains_sensitive_info(text)
    if is_sensitive and delete_after is None:
        delete_after = 60
        
    full_text = format_premium(text, title)

    if len(full_text) > 4096:
        chunks = [full_text[i:i+4000] for i in range(0, len(full_text), 4000)]
        last_msg_id = None
        for i, chunk in enumerate(chunks):
            if i > 0:
                chunk = f"_(cont. {i+1}/{len(chunks)})_\n\n{chunk}"
            last_msg_id = _send_single_message_and_get_id(chunk, parse_mode, retries)
            if last_msg_id and delete_after:
                schedule_deletion(CURRENT_CHAT_ID, last_msg_id, delete_after)
            time.sleep(0.5)
        
        _log_to_dashboard(full_text, "ai")
        if delete_previous:
            delete_message(CURRENT_CHAT_ID, delete_previous)
        return last_msg_id
    
    msg_id = _send_single_message_and_get_id(full_text, parse_mode, retries)
    if msg_id:
        _log_to_dashboard(full_text, "ai")
        if delete_after:
            schedule_deletion(CURRENT_CHAT_ID, msg_id, delete_after)
        if delete_previous:
            delete_message(CURRENT_CHAT_ID, delete_previous)
        try:
            from utils.logger import log_conversation_step
            log_conversation_step(full_text, "ai")
        except:
            pass
        return msg_id
    return None

# Optimized Global Session for connection reuse (Keep-Alive)
_HTTP_SESSION = requests.Session()

def _send_single_message_and_get_id(text, parse_mode="Markdown", retries=3):
    for attempt in range(retries):
        try:
            data = {"chat_id": CURRENT_CHAT_ID, "text": text}
            if parse_mode:
                data["parse_mode"] = parse_mode
            if CURRENT_REPLY_TO:
                data["reply_to_message_id"] = CURRENT_REPLY_TO

            # Reusing global session for faster delivery (zero TLS handshake overhead)
            response = _HTTP_SESSION.post(API_URL + "sendMessage", json=data, timeout=10)
            res_data = response.json()
            
            if response.status_code == 200:
                msg_id = res_data["result"]["message_id"]
                _update_last_message(CURRENT_CHAT_ID, msg_id)
                return msg_id
            
            if response.status_code == 400 and "parse entities" in response.text:
                data.pop("parse_mode", None)
                response = _HTTP_SESSION.post(API_URL + "sendMessage", json=data, timeout=10)
                if response.status_code == 200:
                    return response.json()["result"]["message_id"]
        except:
            pass
        time.sleep(1)
    return None

def send_document(file_path, caption=None, retries=3, delete_after=None, delete_previous=None):
    if not os.path.exists(file_path):
        return False
    
    is_sensitive = contains_sensitive_info(caption) or contains_sensitive_info(file_path)
    if is_sensitive and delete_after is None:
        delete_after = 60

    if os.path.getsize(file_path) > MAX_FILE_SIZE:
        return False
    
    formatted_caption = format_premium(caption) if caption else None

    for attempt in range(retries):
        try:
            with open(file_path, "rb") as doc:
                data = {"chat_id": CURRENT_CHAT_ID}
                if CURRENT_REPLY_TO:
                    data["reply_to_message_id"] = CURRENT_REPLY_TO
                if formatted_caption:
                    data["caption"] = formatted_caption
                    data["parse_mode"] = "Markdown"
                
                response = requests.post(API_URL + "sendDocument", data=data, files={"document": doc}, timeout=300)
                res_data = response.json()
                
                if response.status_code == 200:
                    msg_id = res_data["result"]["message_id"]
                    _update_last_message(CURRENT_CHAT_ID, msg_id)
                    if delete_after:
                        schedule_deletion(CURRENT_CHAT_ID, msg_id, delete_after)
                    if delete_previous:
                        delete_message(CURRENT_CHAT_ID, delete_previous)
                    
                    _log_to_dashboard(f"[DOCUMENT]: {os.path.basename(file_path)}", "ai")
                    return True
        except:
            pass
        time.sleep(1)
    return False

def send_voice(file_path, caption=None, retries=3, delete_after=None, delete_previous=None):
    if not os.path.exists(file_path):
        return False
    
    is_sensitive = contains_sensitive_info(caption)
    if is_sensitive and delete_after is None:
        delete_after = 60

    actual_path = file_path
    converted = False
    if file_path.lower().endswith('.mp3'):
        ogg_path = _convert_to_ogg(file_path)
        if ogg_path:
            actual_path = ogg_path
            converted = True
    
    if os.path.getsize(actual_path) > MAX_FILE_SIZE:
        return False
    
    formatted_caption = format_premium(caption) if caption else None

    for attempt in range(retries):
        try:
            with open(actual_path, "rb") as voice:
                data = {"chat_id": CURRENT_CHAT_ID}
                if CURRENT_REPLY_TO:
                    data["reply_to_message_id"] = CURRENT_REPLY_TO
                if formatted_caption:
                    data["caption"] = formatted_caption
                    data["parse_mode"] = "Markdown"
                
                response = requests.post(API_URL + "sendVoice", data=data, files={"voice": voice}, timeout=120)
                res_data = response.json()
                
                if response.status_code == 200:
                    msg_id = res_data["result"]["message_id"]
                    _update_last_message(CURRENT_CHAT_ID, msg_id)
                    if delete_after:
                        schedule_deletion(CURRENT_CHAT_ID, msg_id, delete_after)
                    if delete_previous:
                        delete_message(CURRENT_CHAT_ID, delete_previous)
                    
                    _log_to_dashboard(f"[VOICE]: {os.path.basename(file_path)}", "ai")
                    if converted and os.path.exists(actual_path):
                        os.remove(actual_path)
                    return True
                
                # Markdown parse error — retry without parse_mode
                if response.status_code == 400 and "parse entities" in response.text.lower():
                    with open(actual_path, "rb") as voice2:
                        data.pop("parse_mode", None)
                        response2 = requests.post(API_URL + "sendVoice", data=data, files={"voice": voice2}, timeout=120)
                        if response2.status_code == 200:
                            msg_id = response2.json()["result"]["message_id"]
                            if delete_after:
                                schedule_deletion(CURRENT_CHAT_ID, msg_id, delete_after)
                            if delete_previous:
                                delete_message(CURRENT_CHAT_ID, delete_previous)
                            _log_to_dashboard(f"[VOICE]: {os.path.basename(file_path)}", "ai")
                            if converted and os.path.exists(actual_path):
                                os.remove(actual_path)
                            return True

                if response.status_code == 400 and attempt == retries - 1:
                    return _send_audio_fallback(actual_path, caption, delete_after=delete_after, delete_previous=delete_previous)
        except:
            pass
        time.sleep(1)
    return False


TELEGRAM_CAPTION_LIMIT = 1024

def send_voice_with_text(voice_path, text, retries=3, delete_after=None, delete_previous=None):
    """
    Combined delivery: Voice note + text as ONE Telegram message.
    - If text ≤ 1024 chars: voice with caption (single message)
    - If text > 1024 chars: text message first, then voice with truncated caption
    """
    if not voice_path or not os.path.exists(voice_path):
        # Fallback: just send text if voice is missing
        return send_message(text, delete_after=delete_after, delete_previous=delete_previous)
    
    if not text:
        return send_voice(voice_path, delete_after=delete_after, delete_previous=delete_previous)

    full_text = format_premium(text)
    
    is_sensitive = contains_sensitive_info(text)
    if is_sensitive and delete_after is None:
        delete_after = 60

    if len(full_text) <= TELEGRAM_CAPTION_LIMIT:
        # SHORT TEXT: Send voice with full text as caption (ONE message)
        result = send_voice(voice_path, caption=text, retries=retries, 
                           delete_after=delete_after, delete_previous=delete_previous)
        if result:
            _log_to_dashboard(full_text, "ai")
            try:
                from utils.logger import log_conversation_step
                log_conversation_step(full_text, "ai")
            except:
                pass
        return result
    else:
        # LONG TEXT: Send text first, then voice with short caption
        # Step 1: Send the full text message
        text_msg_id = _send_single_message_and_get_id(full_text, "Markdown", retries)
        
        if not text_msg_id:
            # Markdown failed, try plain
            text_msg_id = _send_single_message_and_get_id(full_text, None, retries)
        
        # Step 2: Send voice (no caption — text is already above)
        voice_result = send_voice(voice_path, caption=None, retries=retries,
                                  delete_after=delete_after, delete_previous=delete_previous)
        
        if text_msg_id:
            _log_to_dashboard(full_text, "ai")
            if delete_after:
                schedule_deletion(CURRENT_CHAT_ID, text_msg_id, delete_after)
            if delete_previous:
                delete_message(CURRENT_CHAT_ID, delete_previous)
            try:
                from utils.logger import log_conversation_step
                log_conversation_step(full_text, "ai")
            except:
                pass
        
        return voice_result or (text_msg_id is not None)

def _convert_to_ogg(mp3_path):
    ogg_path = mp3_path.rsplit('.', 1)[0] + '_tg.ogg'
    try:
        cmd = ['ffmpeg', '-y', '-i', mp3_path, '-c:a', 'libopus', '-b:a', '32k', '-vbr', 'on', '-application', 'voip', '-ar', '24000', '-ac', '1', ogg_path]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return ogg_path if proc.returncode == 0 and os.path.exists(ogg_path) else None
    except:
        return None

def _send_audio_fallback(file_path, caption=None, retries=2, delete_after=None, delete_previous=None):
    formatted_caption = format_premium(caption) if caption else None
    for attempt in range(retries):
        try:
            with open(file_path, "rb") as audio:
                data = {"chat_id": CURRENT_CHAT_ID, "title": "BANE Voice"}
                if CURRENT_REPLY_TO:
                    data["reply_to_message_id"] = CURRENT_REPLY_TO
                if formatted_caption:
                    data["caption"] = formatted_caption
                    data["parse_mode"] = "Markdown"
                response = requests.post(API_URL + "sendAudio", data=data, files={"audio": audio}, timeout=120)
                if response.status_code == 200:
                    msg_id = response.json()["result"]["message_id"]
                    if delete_after:
                        schedule_deletion(CURRENT_CHAT_ID, msg_id, delete_after)
                    if delete_previous:
                        delete_message(CURRENT_CHAT_ID, delete_previous)
                    return True
        except:
            pass
        time.sleep(1)
    return False
if __name__ == "__main__":
    args = get_args()
    if args.chat_id:
        CURRENT_CHAT_ID = args.chat_id
    if args.reply_to:
        CURRENT_REPLY_TO = args.reply_to

    # Real-time double respond prevention: Auto-delete last message if requested
    if args.delete_auto:
        last_id = get_last_message_id(CURRENT_CHAT_ID)
        if last_id:
            delete_message(CURRENT_CHAT_ID, last_id)

    if args.delete:
        delete_message(CURRENT_CHAT_ID, args.delete)
        sys.exit(0)
        
    text_content = args.text.replace("\\n", "\n") if args.text else None
    del_after = args.delete_after
    del_prev = args.delete_previous
    
    success_id = None
    if args.voice_text:
        # COMBINED MODE: Voice + Text as ONE message
        success_id = send_voice_with_text(args.voice_text, text_content, 
                                          delete_after=del_after, delete_previous=del_prev)
    elif args.document:
        success_id = send_document(args.document, caption=text_content, delete_after=del_after, delete_previous=del_prev)
    elif args.voice:
        success_id = send_voice(args.voice, caption=text_content, delete_after=del_after, delete_previous=del_prev)
    elif text_content:
        success_id = send_message(text_content, title=args.title, parse_mode=args.parse_mode, delete_after=del_after, delete_previous=del_prev)
    
    if success_id:
        if isinstance(success_id, int):
            print(success_id) # Output the ID for the caller to capture
        sys.exit(0)
    sys.exit(1)
