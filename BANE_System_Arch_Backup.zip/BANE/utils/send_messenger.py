# Outbound Messenger Bridge
import requests
import argparse
import os
from dotenv import load_dotenv

# Load Env
dotenv_abs_path = "/home/son/BANE/config/secrets.env"
load_dotenv(dotenv_path=dotenv_abs_path)
if not os.getenv("MESSENGER_PAGE_ACCESS_TOKEN"):
    # Fallback to secondary location if needed
    load_dotenv(dotenv_path=os.path.join(os.getcwd(), "config/secrets.env"))

PAGE_ACCESS_TOKEN = os.getenv("MESSENGER_PAGE_ACCESS_TOKEN")

def send_messenger_text(recipient_id, text, access_token=None, reply_to_mid=None):
    """Send text message via Meta Graph API."""
    token = access_token or PAGE_ACCESS_TOKEN
    if not token:
        print("❌ Error: Missing Access Token")
        return None

    url = f"https://graph.facebook.com/v19.0/me/messages?access_token={token}"
    
    message_payload = {"text": text}
    if reply_to_mid:
        message_payload["reply_to"] = {"message_id": reply_to_mid}
        
    payload = {
        "recipient": {"id": recipient_id},
        "message": message_payload,
        "messaging_type": "RESPONSE"
    }
    try:
        response = requests.post(url, json=payload, timeout=10)
        
        # Retry logic for "reply_to" failure (API v19+ strictness)
        if response.status_code == 400 and "reply_to" in response.text and reply_to_mid:
             print(f"⚠️ 'reply_to' failed. Retrying without reply context...")
             del payload["message"]["reply_to"]
             response = requests.post(url, json=payload, timeout=10)

        if response.status_code != 200:
            print(f"❌ Messenger Error: {response.status_code} - {response.text}")
        response.raise_for_status()
        res_json = response.json()
        try:
            from utils.logger import log_conversation_step
            log_conversation_step(text, "ai", user_id=recipient_id)
            
            # Save for reply context
            from utils.message_history import save_message
            if "message_id" in res_json:
                save_message(res_json["message_id"], text, sender_id="system")
        except:
            pass
        return res_json
    except Exception as e:
        print(f"❌ Failed to send Messenger message: {e}")
        return None

def send_messenger_attachment(recipient_id, file_path, file_type="audio", access_token=None):
    """Send attachment (audio/image) via multipart upload."""
    token = access_token or PAGE_ACCESS_TOKEN
    if not token: return None
    
    url = f"https://graph.facebook.com/v19.0/me/messages?access_token={token}"
    
    payload = {
        "recipient": f'{{"id":"{recipient_id}"}}',
        "message": f'{{"attachment":{{"type":"{file_type}", "payload":{{"is_reusable":true}}}}}}'
    }
    
    try:
        with open(file_path, 'rb') as f:
            files = {
                'filedata': (os.path.basename(file_path), f, 'audio/mpeg' if file_type=='audio' else None)
            }
            # Note: When sending files, 'recipient' and 'message' (partial) must be sent as data
            response = requests.post(url, data=payload, files=files, timeout=60)
            response.raise_for_status()
            res_json = response.json()
            try:
                from utils.logger import log_conversation_step
                log_conversation_step(f"[{file_type.upper()}]: {os.path.basename(file_path)}", "ai", user_id=recipient_id)
                
                # Save for reply context
                from utils.message_history import save_message
                if "message_id" in res_json:
                     save_message(res_json["message_id"], f"[Attachment: {file_type}]", sender_id="system", attachments=[{"path": file_path, "type": file_type}])
            except:
                pass
            return res_json
    except Exception as e:
        print(f"❌ Failed to send attachment: {e}")
        return None

async def send_messenger_action(recipient_id, action="mark_seen", access_token=None):
    """
    Sends a sender_action (typing_on, typing_off, mark_seen).
    Async to avoid blocking the router loop.
    """
    token = access_token or PAGE_ACCESS_TOKEN
    if not token: return
    
    url = f"https://graph.facebook.com/v19.0/me/messages?access_token={token}"
    
    payload = {
        "recipient": {"id": recipient_id},
        "sender_action": action
    }
    
    try:
        requests.post(url, json=payload, timeout=5)
    except Exception as e:
        print(f"❌ Failed to send action {action}: {e}")

def send_messenger_reaction(recipient_id, message_id, reaction, access_token=None):
    """
    Send a message reaction (emoji) to a specific message via Meta Graph API.
    Uses POST /me/messages with sender_action='react'.
    Ref: https://developers.facebook.com/docs/messenger-platform/send-messages/
    """
    import logging
    logger = logging.getLogger(__name__)
    
    token = access_token or PAGE_ACCESS_TOKEN
    if not token:
        logger.error("❌ Reaction Error: Missing Access Token")
        return None

    url = f"https://graph.facebook.com/v19.0/me/messages?access_token={token}"
    
    payload = {
        "recipient": {"id": str(recipient_id)},
        "sender_action": "react",
        "payload": {
            "message_id": str(message_id),
            "reaction": reaction
        }
    }
    
    try:
        response = requests.post(url, json=payload, timeout=10)
        
        if response.status_code == 200:
            logger.info(f"✅ Reaction sent successfully: {reaction} → MID:{message_id[:20]}...")
            return response.json()
        else:
            error_body = response.text
            logger.error(f"❌ Reaction API Error [{response.status_code}]: {error_body}")
            
            # Retry with alternate payload format (some API versions differ)
            alt_payload = {
                "recipient": {"id": str(recipient_id)},
                "sender_action": "react",
                "payload": {
                    "message_id": str(message_id),
                    "reaction": reaction.encode('unicode_escape').decode('ascii') if len(reaction.encode('utf-8')) > 4 else reaction
                }
            }
            
            # Only retry if it was a 400 (bad request) — might be encoding issue
            if response.status_code == 400:
                logger.info(f"🔄 Retrying reaction with alternate encoding...")
                retry_response = requests.post(url, json=alt_payload, timeout=10)
                if retry_response.status_code == 200:
                    logger.info(f"✅ Reaction sent on retry: {reaction}")
                    return retry_response.json()
                else:
                    logger.error(f"❌ Retry also failed [{retry_response.status_code}]: {retry_response.text}")
            
            return None
    except Exception as e:
        logger.error(f"❌ Failed to send reaction (exception): {e}")
        return None

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Send Message via Facebook Messenger")
    parser.add_argument("text", nargs="?", help="Message text")
    parser.add_argument("--recipient_id", required=True, help="Recipient PSID")
    parser.add_argument("--token", help="Page Access Token")
    parser.add_argument("--attachment", help="Path to attachment file")
    parser.add_argument("--type", default="audio", help="Attachment type (audio, image, file)")
    parser.add_argument("--reply_to", help="Message ID to reply to")
    parser.add_argument("--react", help="Emoji to react with (requires --target_mid)")
    parser.add_argument("--target_mid", help="Message ID to react to")
    
    args = parser.parse_args()
    
    text_content = args.text.replace("\\n", "\n") if args.text else None
    
    if args.react:
        if not args.target_mid:
            print("Error: --react requires --target_mid")
            exit(1)
        res = send_messenger_reaction(args.recipient_id, args.target_mid, args.react, args.token)
    elif args.attachment:
        res = send_messenger_attachment(args.recipient_id, args.attachment, args.type, args.token)
    elif text_content:
        res = send_messenger_text(args.recipient_id, text_content, args.token, reply_to_mid=args.reply_to)
    else:
        print("Error: Provide 'text', '--attachment', or '--react'")
        exit(1)

    if res:
        try:
            from utils.logger import log_conversation_step
            log_conversation_step(args.text if args.text else f"[Reaction: {args.react}]", "ai", user_id=args.recipient_id)
        except:
            pass
        if not args.react:
            print(f"✅ Sent. ID: {res.get('message_id')}")
        else:
            print("✅ Reaction sent successfully.")
    else:
        exit(1)
