#!/usr/bin/env python3
import argparse
import sys
import logging
import os
import json
from dotenv import load_dotenv

# Import specific senders
from utils.send_messenger import send_messenger_text
from utils.send_telegram import send_message

# Setup Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def solve_telegram_global(chat_id):
    import utils.send_telegram
    utils.send_telegram.CURRENT_CHAT_ID = chat_id

def spawn_voice_background(txt, plat, rid, tok=None):
    import subprocess
    cmd = [
        sys.executable, "utils/universal_reply.py", 
        "--background_voice", 
        txt, 
        "--platform", plat, 
        "--recipient_id", str(rid)
    ]
    if tok:
        cmd.extend(["--token", tok])
        
    subprocess.Popen(cmd, start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def send_universal(platform, recipient_id, text, access_token=None):
    """
    Routes the message to the correct platform (Text Only).
    """
    platform = platform.lower()
    logger.info(f"Routing Reply -> Platform: {platform} | Recipient: {recipient_id}")
    
    if platform == "messenger":
        try:
            res = send_messenger_text(recipient_id, text, access_token)
            if res:
                logger.info(f"✅ Messenger reply sent. MID: {res.get('message_id')}")
                return True
        except Exception as e:
            logger.error(f"❌ Messenger send failed: {e}")
            return False
            
    elif platform == "telegram":
        try:
            solve_telegram_global(int(recipient_id))
            msg_id = send_message(text, parse_mode="Markdown")
            if msg_id:
                logger.info(f"✅ Telegram reply sent. ID: {msg_id}")
                return True
        except Exception as e:
            logger.error(f"❌ Telegram send failed: {e}")
            return False
            
    else:
        logger.error(f"❌ Unknown platform: {platform}")
        return False

def handle_background_voice(text, platform, recipient_id, access_token=None):
    """
    Worker function for background voice processing.
    """
    try:
        from utils.text_to_speech import text_to_mp3, text_to_ogg
        if platform == "messenger":
            from utils.send_messenger import send_messenger_attachment
            success, audio_path = text_to_mp3(text, voice_id="nova")
            if success and audio_path:
                send_messenger_attachment(recipient_id, audio_path, "audio", access_token)
                if os.path.exists(audio_path):
                    os.remove(audio_path)
                    
        elif platform == "telegram":
            import requests
            success, audio_path = text_to_ogg(text, voice_id="nova")
            if success and audio_path:
                token = os.getenv("TELEGRAM_BOT_TOKEN")
                if not token:
                     from utils.send_telegram import BOT_TOKEN
                     token = BOT_TOKEN
                
                if token:
                    url = f"https://api.telegram.org/bot{token}/sendVoice"
                    with open(audio_path, 'rb') as f:
                        requests.post(url, data={'chat_id': recipient_id}, files={'voice': f})
                
                if os.path.exists(audio_path):
                    os.remove(audio_path)
    except Exception:
        pass

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Universal Reply Sender")
    parser.add_argument("text", help="Message text")
    parser.add_argument("--platform", required=True, choices=["telegram", "messenger"], help="Target Platform")
    parser.add_argument("--recipient_id", required=True, help="Chat ID or User ID")
    parser.add_argument("--token", help="Messenger Access Token (optional for telegram)")
    parser.add_argument("--background_voice", action="store_true", help="Internal flag for background voice processing")
    parser.add_argument("--no_voice", action="store_true", help="Specifically disable voice for this call")
    parser.add_argument("--prompt", help="Original user prompt for Cortex Memory storage", default="N/A (AI Generated)")
    
    args = parser.parse_args()
    
    if args.background_voice:
        handle_background_voice(args.text, args.platform, args.recipient_id, args.token)
        sys.exit(0)
    
    # 1. Send Text
    # Process escaped newlines for CLI usage
    args.text = args.text.replace("\\n", "\n")
    
    success = send_universal(args.platform, args.recipient_id, args.text, args.token)
    
    # 2. Trigger Voice if allowed
    if success:
        # --- CORTEX STORAGE INTEGRATION (Independent of Voice) ---
        try:
            from core.cortex_recall import store_cortex
            from utils.user_manager import get_user_paths
            u_paths = get_user_paths(args.recipient_id, platform=args.platform)
            u_hash = u_paths.get('hash')
            if u_hash:
                # Use provided prompt or default
                store_cortex(u_hash, args.prompt, args.text)
        except Exception as e:
            logger.debug(f"Cortex storage failed: {e}")
        # ----------------------------------

    if success and not args.no_voice:

        # Check User Settings
        voice_enabled = True # Default
        try:
             from utils.user_manager import get_user_paths
             paths = get_user_paths(args.recipient_id, platform=args.platform)
             settings_path = os.path.join(paths['storage'], "settings.json")
             if os.path.exists(settings_path):
                 with open(settings_path, 'r') as f:
                     settings = json.load(f)
                     voice_enabled = settings.get("voice_enabled", True)
        except Exception:
             pass
             
        # Allow voice if explicitly requested in text (with safeguard against 'remove/off' mentions)
        text_lower = args.text.lower()
        voice_keywords = ["voice", "audio", "boses", "salita", "speech", "pagsasalita"]
        off_keywords = ["remove", "tanggal", "stop", "off", "disable", "huwag", "wag", "paki-remove", "alisin"]
        
        has_voice_kw = any(kw in text_lower for kw in voice_keywords)
        has_off_kw = any(kw in text_lower for kw in off_keywords)
        
        voice_requested = has_voice_kw and not has_off_kw
        
        if voice_enabled or voice_requested:
            spawn_voice_background(args.text, args.platform, args.recipient_id, args.token)

    if not success:
        sys.exit(1)
