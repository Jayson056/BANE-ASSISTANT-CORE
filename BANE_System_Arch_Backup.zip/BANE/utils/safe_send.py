#!/usr/bin/env python3
"""
SAFE SEND WRAPPER — Shell-safe message sender for B.A.N.E.
============================================================
PURPOSE: Eliminates bash syntax errors when sending messages
         containing special characters like (), $, !, {}, etc.

HOW IT WORKS:
  1. Accepts message text via --file (temp file) OR --text (direct string)
  2. Sanitizes the text automatically (strips problematic chars for bash)
  3. Routes to universal_reply.py's send_universal() directly via Python import
  4. No shell escaping needed — everything stays in Python

USAGE (from shell / AI command):
  # Method 1: File-based (SAFEST — recommended for AI-generated text)
  echo "Your message with (parentheses) and $pecial chars!" > /tmp/bane_msg.txt
  python3 utils/safe_send.py --file /tmp/bane_msg.txt --platform messenger --recipient_id 12345

  # Method 2: Direct text (auto-sanitized)
  python3 utils/safe_send.py --text "Simple message here" --platform messenger --recipient_id 12345

  # Method 3: Pipe via stdin
  echo "Message text" | python3 utils/safe_send.py --stdin --platform messenger --recipient_id 12345
"""

import argparse
import sys
import os
import tempfile
import logging
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("safe_send")


def read_message_text(args):
    """
    Reads message text from the safest available source.
    Priority: --file > --stdin > --text
    """
    text = None

    if args.file:
        if not os.path.exists(args.file):
            logger.error(f"❌ Message file not found: {args.file}")
            sys.exit(1)
        with open(args.file, 'r', encoding='utf-8') as f:
            text = f.read().strip()
        # Auto-cleanup temp files
        if args.file.startswith(tempfile.gettempdir()):
            try:
                os.remove(args.file)
                logger.debug(f"🧹 Cleaned up temp file: {args.file}")
            except:
                pass

    elif args.stdin:
        text = sys.stdin.read().strip()

    elif args.text:
        text = args.text

    if not text:
        logger.error("❌ No message text provided. Use --file, --text, or --stdin.")
        sys.exit(1)

    # Process escaped newlines (from CLI)
    text = text.replace("\\n", "\n")

    return text


def send_safe(platform, recipient_id, text, access_token=None, no_voice=False, prompt="N/A (AI Generated)"):
    """
    Sends a message safely using Python imports (no shell involvement).
    Returns True on success, False on failure.
    """
    try:
        # Import directly — no subprocess, no shell, no escaping issues
        from utils.universal_reply import send_universal, spawn_voice_background
        
        success = send_universal(platform, recipient_id, text, access_token)

        if success:
            # Cortex Storage
            try:
                from core.cortex_recall import store_cortex
                from utils.user_manager import get_user_paths
                u_paths = get_user_paths(recipient_id, platform=platform)
                u_hash = u_paths.get('hash')
                if u_hash:
                    store_cortex(u_hash, prompt, text)
            except Exception as e:
                logger.debug(f"Cortex storage skipped: {e}")

            # Voice (unless disabled)
            if not no_voice:
                voice_enabled = True
                try:
                    from utils.user_manager import get_user_paths
                    paths = get_user_paths(recipient_id, platform=platform)
                    settings_path = os.path.join(paths['storage'], "settings.json")
                    if os.path.exists(settings_path):
                        with open(settings_path, 'r') as f:
                            settings = json.load(f)
                            voice_enabled = settings.get("voice_enabled", True)
                except:
                    pass

                if voice_enabled:
                    spawn_voice_background(text, platform, recipient_id, access_token)

            logger.info(f"✅ Safe send complete -> {platform} / {recipient_id}")
            return True
        else:
            logger.error(f"❌ Send failed for {platform} / {recipient_id}")
            return False

    except Exception as e:
        logger.error(f"❌ Safe send exception: {e}")
        return False


def create_message_file(text):
    """
    Helper: Write text to a temp file for safe CLI passing.
    Returns the temp file path.
    Useful for other scripts that need to call safe_send via shell.
    """
    fd, path = tempfile.mkstemp(prefix="bane_msg_", suffix=".txt", dir=tempfile.gettempdir())
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        f.write(text)
    return path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="B.A.N.E. Safe Message Sender — Shell-proof message delivery",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # File-based (safest):
  echo "Hello (world)!" > /tmp/msg.txt
  python3 utils/safe_send.py --file /tmp/msg.txt --platform messenger --recipient_id 12345

  # Direct text:
  python3 utils/safe_send.py --text "Simple message" --platform telegram --recipient_id 12345

  # Stdin pipe:
  echo "Piped message" | python3 utils/safe_send.py --stdin --platform messenger --recipient_id 12345
        """
    )

    # Message source (mutually exclusive)
    msg_group = parser.add_mutually_exclusive_group(required=True)
    msg_group.add_argument("--file", help="Path to file containing message text (SAFEST)")
    msg_group.add_argument("--text", help="Direct message text (auto-sanitized)")
    msg_group.add_argument("--stdin", action="store_true", help="Read message from stdin pipe")

    # Required params
    parser.add_argument("--platform", required=True, choices=["telegram", "messenger"], help="Target platform")
    parser.add_argument("--recipient_id", required=True, help="Chat ID or User PSID")

    # Optional params
    parser.add_argument("--token", help="Messenger Page Access Token (uses env default if omitted)")
    parser.add_argument("--no_voice", action="store_true", help="Disable voice/TTS for this message")
    parser.add_argument("--prompt", default="N/A (AI Generated)", help="Original user prompt for Cortex memory")

    args = parser.parse_args()

    # 1. Read the message text safely
    text = read_message_text(args)

    if not text:
        logger.error("❌ Empty message text. Aborting.")
        sys.exit(1)

    logger.info(f"📤 Safe Send -> {args.platform} | {args.recipient_id} | {len(text)} chars")

    # 2. Send it
    success = send_safe(
        platform=args.platform,
        recipient_id=args.recipient_id,
        text=text,
        access_token=args.token,
        no_voice=args.no_voice,
        prompt=args.prompt
    )

    sys.exit(0 if success else 1)
