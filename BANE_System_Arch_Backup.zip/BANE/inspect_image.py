import sys
import pytesseract
import cv2
import numpy as np

def inspect_image(path):
    img = cv2.imread(path)
    if img is None:
        print(f"Error: Could not read image at {path}")
        return
    
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # Basic enhancement
    if np.mean(gray) < 127:
        gray = cv2.bitwise_not(gray)
    
    text = pytesseract.image_to_string(gray)
    print("--- OCR START ---")
    print(text)
    print("--- OCR END ---")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        inspect_image(sys.argv[1])
    else:
        print("Usage: python3 inspect_image.py <path>")
