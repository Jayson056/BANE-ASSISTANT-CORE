#!/bin/bash
# CLAWBOLT Messenger Interface - Startup Script
# Supports both development (Flask) and production (Gunicorn) modes

CLAWBOLT_DIR="/home/son/CLAWBOLT"
VENV="$CLAWBOLT_DIR/.venv"
SECRETS="$CLAWBOLT_DIR/config/secrets.env"

# Check for .env file
if [ ! -f "$SECRETS" ]; then
    echo "❌ Missing config/secrets.env"
    exit 1
fi

MODE="${1:-dev}"

if [ "$MODE" == "prod" ] || [ "$MODE" == "production" ]; then
    echo "🚀 Starting CLAWBOLT Messenger Gateway [PRODUCTION] on Port 8082..."
    echo "   Using Gunicorn with 2 workers + 4 threads"
    echo ""
    echo "👉 Public Endpoints (via ngrok):"
    echo "   - /privacy"
    echo "   - /terms"
    echo "   - /webhook"
    echo ""

    cd "$CLAWBOLT_DIR"
    exec "$VENV/bin/gunicorn" \
        --bind 0.0.0.0:8082 \
        --workers 2 \
        --threads 4 \
        --timeout 120 \
        --graceful-timeout 30 \
        --access-logfile "$CLAWBOLT_DIR/Debug/Console/messenger_access.log" \
        --error-logfile "$CLAWBOLT_DIR/Debug/Console/messenger_error.log" \
        --capture-output \
        messenger_interface.app:app
else
    echo "🚀 Starting CLAWBOLT Messenger Gateway [DEV] on Port 8082..."
    echo "👉 Public Endpoints (via ngrok):"
    echo "   - /privacy"
    echo "   - /terms"
    echo "   - /webhook"
    echo ""

    cd "$CLAWBOLT_DIR"
    "$VENV/bin/python3" messenger_interface/app.py
fi
