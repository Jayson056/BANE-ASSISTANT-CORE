
import sys
import os

# Append BANE to path to import core.security
sys.path.append("/home/son/BANE")
from core.security import is_allowed_path

# TEST CASES
tests = [
    ("/home/son/BANE/core/router.py", "Core Logic"),
    ("/home/son/BANE/antigravity/AI_SKILLS_DIR/CYBER_SECURITY.skill", "Skill Definition"),
    ("/home/son/BANE_Workspaces/USER-DATA/de75103189587dd4/School/homework.py", "Workplace Code"),
    ("/home/son/BANE/storage/test_log.json", "System Whitelist (Storage)"),
]

print("🛡️ BANE FINAL SECURITY AUDIT REPORT")
print("========================================")
for path, label in tests:
    allowed = is_allowed_path(path)
    status = "✅ ALLOWED" if allowed else "❌ BLOCKED"
    print(f"{label:<25}: {status}")
    print(f"   Path: {path}")

print("========================================")
print("CONCLUSION: Core is IMMUTABLE. Workplace is MANAGEABLE.")
