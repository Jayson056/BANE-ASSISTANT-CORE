
import sys
import os
sys.path.append("/home/son/BANE")
from core.security import is_locked, is_allowed_path

workspace_path = "/home/son/BANE_Workspaces/USER-DATA/de75103189587dd4/School/test.txt"
core_path = "/home/son/BANE/core/router.py"

print(f"System Locked: {is_locked()}")
print(f"Can edit workplace? ({workspace_path}): {is_allowed_path(workspace_path)}")
print(f"Can edit core logic? ({core_path}): {is_allowed_path(core_path)}")
