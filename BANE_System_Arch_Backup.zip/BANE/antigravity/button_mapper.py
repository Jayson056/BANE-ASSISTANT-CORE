# BANE - Created by Jayson056
# Copyright (c) 2026 Jayson056. All rights reserved.
import logging
from utils.ocr_helper import run_optimized_ocr
from antigravity.window import get_antigravity_geometry

logger = logging.getLogger(__name__)

# Keywords to identify action buttons
ACCEPT_KEYWORDS = ["accept", "apply", "confirm", "allow once", "allow this conversation"]
REJECT_KEYWORDS = ["reject", "dismiss", "cancel", "discard", "deny"]
ALL_KEYWORD = "all"
ALLOW_KEYWORDS = ["allow", "access"]
ALWAYS_RUN_KEYWORDS = ["always run", "run automatically", "auto run"]

def detect_action_buttons():
    """
    Scan the screen for Accept ALL and Reject ALL buttons using phrase detection.
    
    Returns:
        dict or None: {"accept_all": (x, y), "reject_all": (x, y)} if found, else None
    """
    try:
        # Lazy import to support headless backend
        import pyautogui
        
        geo = get_antigravity_geometry()
        win_x, win_y = (geo[0], geo[1]) if geo else (0, 0)
        
        # Run OCR with detailed output
        # Downscale 0.7 for button detection accuracy
        scale = 0.7
        data = run_optimized_ocr(crop_to_window=True, downscale=scale, output_type="dict")
        
        if not data or "text" not in data:
            return None
            
        screen_width, screen_height = pyautogui.size()
        detected = {}
        
        # We search for sequences like "Accept" + "all" on the same line
        for i, text in enumerate(data["text"]):
            text_clean = text.lower().strip()
            if not text_clean:
                continue
            
            y = data["top"][i]
            x = data["left"][i]
            
            # Context window - look for a phrase on the same line
            context_parts = []
            for j in range(max(0, i-2), min(len(data["text"]), i+3)):
                if abs(data["top"][j] - y) < (15 * scale):
                    context_parts.append(data["text"][j].strip().lower())
            
            full_phrase = " ".join(context_parts)
            
            is_accept_all = "accept all" in full_phrase or "apply all" in full_phrase
            is_reject_all = "reject all" in full_phrase or "dismiss all" in full_phrase or "discard all" in full_phrase
            is_allow_once = "allow once" in full_phrase
            is_allow_conv = "allow this conversation" in full_phrase or "allow conversion" in full_phrase
            is_always_run = any(kw in full_phrase for kw in ALWAYS_RUN_KEYWORDS) or "always run" in full_phrase

            # Adjust for scale and window
            actual_x = int((x + data["width"][i] // 2) / scale) + win_x
            actual_y = int((y + data["height"][i] // 2) / scale) + win_y
            
            # Context-aware mapping
            if is_accept_all and text_clean in ["accept", "apply"]:
                detected["accept_all"] = (actual_x, actual_y)
            
            if is_reject_all and text_clean in ["reject", "dismiss", "discard"]:
                detected["reject_all"] = (actual_x, actual_y)

            if is_allow_once and text_clean in ["allow", "once"]:
                detected["allow_once"] = (actual_x, actual_y)

            if is_allow_conv and text_clean in ["allow", "this", "conversation"]:
                detected["allow_conv"] = (actual_x, actual_y)
            
            if is_always_run and (text_clean in ["always", "run", "auto"]):
                detected["always_run"] = (actual_x, actual_y)

        if detected:
            return detected
        
        # Fallback 2: Try looking for just keywords if phrase matching failed
        for i, text in enumerate(data["text"]):
            text_clean = text.lower().strip()
            actual_x = int((data["left"][i] + data["width"][i]//2) / scale) + win_x
            if text_clean in ["accept", "reject"] and actual_x > screen_width * 0.6:
                 key = f"{text_clean}_all"
                 if key not in detected:
                      actual_y = int((data["top"][i] + data["height"][i]//2) / scale) + win_y
                      detected[key] = (actual_x, actual_y)
        
        return detected if detected else None
        
    except Exception as e:
        logger.error(f"Button detection failed: {e}")
        return None


def click_button(coords):
    """
    Click at the specified coordinates.
    
    Args:
        coords (tuple): (x, y) coordinates to click
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Lazy import to support headless backend
        import pyautogui
        import time
        
        x, y = coords
        logger.info(f"Clicking button at ({x}, {y})")
        
        # Move to position
        pyautogui.moveTo(x, y, duration=0.2)
        time.sleep(0.1)
        
        # Click
        pyautogui.click(x, y)
        logger.info(f"Successfully clicked at ({x}, {y})")
        
        return True
        
    except Exception as e:
        logger.error(f"Failed to click button at {coords}: {e}")
        return False
