# BANE - Created by Jayson056
# Copyright (c) 2026 Jayson056. All rights reserved.
import time
import logging
from antigravity.window import focus_antigravity
from antigravity.mapper import locate_input_box

logger = logging.getLogger(__name__)

from antigravity.skill_manager import get_skill_header

# Global session and cache states (lowers token consumption/io)
_cached_context = None
_session_initialized = False

def get_context():
    """Fetches and caches the skill header to avoid redundant DISK I/O."""
    global _cached_context
    if _cached_context is None:
        _cached_context = get_skill_header()
    return _cached_context

def smart_wait(seconds=0.5):
    """Refined polling wait for better UI responsiveness."""
    start = time.time()
    while time.time() - start < seconds:
        time.sleep(0.01)

def close_all_editor_tabs():
    """
    Close all open editor tabs in Antigravity to prevent:
    1. Open code files being read as AI context (extra token consumption)
    2. Code content being referenced/sent back to users in responses
    Uses VS Code keyboard shortcut: Ctrl+K, Ctrl+W (Close All Editors)
    """
    try:
        import pyautogui
        # Ctrl+K, Ctrl+W = Close All Editors in VS Code / Antigravity
        pyautogui.hotkey('ctrl', 'k')
        time.sleep(0.15)
        pyautogui.hotkey('ctrl', 'w')
        time.sleep(0.3)
        logger.info("🧹 Closed all editor tabs before injection (token optimization)")
    except Exception as e:
        logger.warning(f"Failed to close editor tabs: {e}")

def send_to_antigravity(user_text, **kwargs):
    if kwargs:
        logger.warning(f"send_to_antigravity received extra args: {kwargs}")
    """
    Focus window, find input box, and inject text.
    Returns (success, message).
    """
    if not focus_antigravity():
        return False, "Antigravity window not found"

    # Wait for window to settle/render
    time.sleep(0.1) # Optimized from 0.3

    location = None
    for attempt in range(3):
        location = locate_input_box()
        if location:
            break
        logger.warning(f"Input box not found (attempt {attempt+1}/3). Retrying...")
        time.sleep(0.5) # Optimized from 1.0

    if not location:
        return False, "Input box not detected after retries"

    x, y = location
    import pyautogui
    from antigravity.window import is_point_in_safe_window
    screen_width, screen_height = pyautogui.size()
    
    # 2D Editor Zone Protection (Stronger Awareness)
    editor_x_min, editor_x_max = screen_width * 0.25, screen_width * 0.75
    editor_y_min, editor_y_max = screen_height * 0.15, screen_height * 0.85
    
    if (editor_x_min < x < editor_x_max) and (editor_y_min < y < editor_y_max):
        if not is_point_in_safe_window(x, y):
            logger.error(f"🛑 Blocking injection: Target {x, y} is in forbidden Editor Zone (2D).")
            return False, "Targeting error: Refusing to paste into editor zone."
        else:
            logger.info(f"Allowing injection at {x, y} (Confirmed SAFE window)")

    try:
        import pyperclip
        
        # 1. Click to focus the input box
        pyautogui.click(x, y)
        smart_wait(0.1) # Optimized from 0.2
        
        # 2. Optimized Content Construction (TOKEN SAVER)
        global _session_initialized
        context = get_context()
        
        # Header only on first injection of session to save thousands of tokens
        if not _session_initialized:
            full_text = f"{context}\n\n{user_text}"
            # Also close tabs only once per session/switch to save ~0.5s per message
            close_all_editor_tabs()
            _session_initialized = True
        else:
            full_text = user_text
            
        # Conditional Footer (Prevents Redundancy)
        if "provided script based on user id" not in full_text:
            full_text += "\n\n(IMPORTANT: Send your response using the provided script based on user id)"
            
        # UI Safety: Truncate if extreme (prevents clipboard/editor freeze)
        if len(full_text) > 12000:
            logger.warning(f"Truncating long prompt ({len(full_text)} chars) for UI safety.")
            full_text = full_text[:12000]
            
        pyperclip.copy(full_text)
        
        # 3. Clean and Paste (OVERWRITE MODE)
        # We select all and then paste directly — no need for backspace.
        pyautogui.hotkey('ctrl', 'a')
        smart_wait(0.05) # Optimized from 0.1
        
        pyautogui.hotkey('ctrl', 'v')
        smart_wait(0.05) # Optimized from 0.1
        
        # 4. SEND (Single Enter Execution)
        pyautogui.press("enter")
        
        return True, "Message sent to Antigravity"
    except Exception as e:
        logger.error(f"Injection failed: {e}")
        try:
            from antigravity.skill_manager import get_current_skill, update_skill_analytics
            update_skill_analytics(get_current_skill(), error=True, message=f"Injection failed: {e}")
        except:
            pass
        return False, f"Injection error: {e}"